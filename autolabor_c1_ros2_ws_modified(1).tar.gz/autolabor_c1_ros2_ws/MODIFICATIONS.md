# 修改记录

本文档记录相对原始交付包所做的所有修改。

修改日期：2026-08-29
测试机器：ASUS TUF Gaming FA608FM（Ubuntu 22.04，ROS2 Humble）

## 1. C++ 编译修复

文件：src/pantilt_camera_serial/src/pantilt_serial_control.cpp 第 25 行

问题：std::max(1, declare_parameter<int>(...)) 中 1 是 int 字面量，编译器无法自动推导模板类型，导致编译失败。

修改：
- std::max(1, declare_parameter<int>("default_stable_samples", 3))
+ std::max<int>(1, declare_parameter<int>("default_stable_samples", 3))

## 2. 相机驱动替换

原因：usb_cam 在目标相机上帧率极低（4K 0.15 Hz，1080p 2-3 Hz）。
v4l2-ctl 直测可稳定 30 fps，说明问题在 usb_cam 的 mmap IO 实现。

新增：src/opencv_camera_node/
基于 OpenCV VideoCapture 的 ROS2 相机节点，与 ROS1 的 cv_camera 底层一致。
1080p MJPG 稳定 27-28 fps。

## 3. 启动文件修改

文件：src/autolabor_c1_bringup/launch/autolabor_c1.launch.py

| 修改项 | 原始 | 修改后 |
|---|---|---|
| 相机节点包 | usb_cam | opencv_camera_node |
| 默认设备路径 | /dev/video4 | /dev/video0 |
| 默认分辨率 | 3840x2160 | 1920x1080 |
| 参数传递方式 | ParameterValue + value_type | LaunchConfiguration |

## 4. 新增拍照脚本

save_with_angle.py：手动拍一张，文件名带云台角度
auto_save_with_angle.py：每 60 帧自动保存一张
两个脚本均使用 qos_profile_sensor_data 订阅角度话题

## 5. CMakeLists.txt 修改

新增两个脚本的安装注册：save_with_angle.py 和 auto_save_with_angle.py

## 6. 文档更新

README.md：设备路径、相机驱动、分辨率、推荐参数
快速上手.md：启动命令、参数表
VERIFICATION.md：新增实机验证结果
MODIFICATIONS.md：新增本文档

## 7. 实测推荐参数

| 参数 | 原始默认值 | 推荐值 | 原因 |
|---|---|---|---|
| image_width | 3840 | 1920 | 4K 解码过慢 |
| image_height | 2160 | 1080 | 4K 解码过慢 |
| tolerance | 1.5 | 3.0 | 云台到位偏差 1-2.5 度 |
| timeout | 8.0 | 20.0 | 大角度运动不够 |
| stable_samples | 3 | 2 | 减少等待 |
| settle_time | 0.25 | 0.5 | 到位后等更久 |
| image_timeout | 2.0 | 5.0 | 给图像更多时间 |

## 8. QoS 兼容性说明

PantiltAngleInfo 话题使用 SensorDataQoS（best_effort）。
订阅此话题必须使用 qos_profile_sensor_data，否则 QoS 不匹配无法接收数据。
